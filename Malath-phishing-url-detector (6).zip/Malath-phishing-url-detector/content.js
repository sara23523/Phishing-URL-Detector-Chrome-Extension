// 1) Inject jsQR library exactly once
if (!window.jsQRInjected) {
  const jsQrScript = document.createElement('script');
  jsQrScript.src = chrome.runtime.getURL('libs/jsQR.js');
  jsQrScript.onload = () => {
    window.jsQRInjected = true;
    console.log('jsQR loaded');
    extractUrlsFromPage();
  };
  (document.head || document.documentElement).appendChild(jsQrScript);
} else {
  extractUrlsFromPage(); // Already loaded
}


// 2) URL validation helper
function isValidURL(str) {
  if (typeof str !== 'string') return false;
  if (/\$\{.*?\}/.test(str)) return false;
  try {
    const url = new URL(str);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch (_) {
    return false;
  }
}

// 2) Main page URL + QR extraction
async function extractUrlsFromPage() {
  const urls = [];
  document.querySelectorAll('a[href]').forEach(a => {
    if (isValidURL(a.href)) {
      urls.push(a.href);
    }
  });

  for (const img of document.images) {
    if (!img.complete) {
      await new Promise(res => img.addEventListener('load', res, { once: true }));
    }
    const qrUrl = await scanImageForQR(img);
    if (qrUrl && isValidURL(qrUrl)) urls.push(qrUrl);
  }

  // Send all found URLs back to background for classification
  chrome.runtime.sendMessage({ action: "scan_urls", urls });

  chrome.storage.local.set({ scannedUrls: urls });
}

// 3) Helper to scan one <img> for a QR code
async function scanImageForQR(imgElement) {
  return new Promise(resolve => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const image = new Image();
    image.crossOrigin = 'anonymous';
    image.src = imgElement.src;

    image.onload = () => {
      // match the natural dimensions for accurate scanning
      canvas.width = image.naturalWidth;
      canvas.height = image.naturalHeight;
      ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
      try {
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, canvas.width, canvas.height);
        resolve(code ? code.data : null);
      } catch (e) {
        console.warn('Unable to scan QR (CORS/taint):', imgElement.src, e);
        resolve(null);
      }
    };

    image.onerror = () => resolve(null);
  });
}


extractUrlsFromPage();
