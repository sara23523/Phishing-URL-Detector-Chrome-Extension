document.addEventListener('DOMContentLoaded', () => {
  const status        = document.getElementById('status');
  const totalScanned  = document.getElementById('totalScanned');
  const totalUnsafe   = document.getElementById('totalUnsafe');
  const resultsList   = document.getElementById('results');
  const langToggle    = document.getElementById('langToggle');
  const darkToggle    = document.getElementById('darkToggle');

  let language = 'en';

  // Your existing translations object (add scanned/unsafe labels if needed)
  const translations = {
    en: {
      title:       'Phishing Detector',
      scanning:    'Scanning...',
      safe:        'This page is Safe ✅',
      suspicious:  'This page may be Suspicious ⚠️',
      scannedLbl:  'URLs scanned',
      unsafeLbl:   'Suspicious URLs',
    },
    ar: {
      title:       'كاشف التصيد الاحتيالي',
      scanning:    'جاري الفحص...',
      safe:        'الصفحة آمنة ✅',
      suspicious:  'قد تكون الصفحة مشبوهة ⚠️',
      scannedLbl:  'عدد الروابط الممسوحة',
      unsafeLbl:   'روابط مشبوهة',
    }
  };

  function translateUI() {
    document.getElementById('title').textContent       = translations[language].title;
    status.textContent                                  = translations[language].scanning;
    totalScanned.textContent                            = '0';
    totalUnsafe.textContent                             = '0';
    document.getElementById('labelScanned').textContent = translations[language].scannedLbl;
    document.getElementById('labelUnsafe').textContent  = translations[language].unsafeLbl;
    document.body.setAttribute('dir', language === 'ar' ? 'rtl' : 'ltr');
  }

  langToggle.addEventListener('click', () => {
    language = language === 'en' ? 'ar' : 'en';
    startScan();
  });
  darkToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
  });

  function renderResults(results) {
    // total URLs scanned
    const total = results.length;
    // URLs classified as phishing (classification '0')
    const unsafe = results.filter(r => r.classification.trim() === '0').length;

    totalScanned.textContent = total;
    totalUnsafe.textContent  = unsafe;

    // Optional: keep showing the detailed list if you want
    //resultsList.innerHTML = '';
    //results.forEach(({ url, classification }) => {
     // const li = document.createElement('li');
     // li.textContent = `${url} → ${classification}`;
     // li.style.color = classification.trim() === '0' ? 'red' : 'green';
    //  resultsList.appendChild(li);
   // });

    // Final status line
    status.textContent = unsafe > 0
      ? translations[language].suspicious
      : translations[language].safe;
  }

  // Listen for when background writes scanResults
  chrome.storage.onChanged.addListener(changes => {
    if (changes.scanResults && changes.scanResults.newValue) {
      renderResults(changes.scanResults.newValue);
    }
  });

  chrome.storage.local.get('scanResults', (data) => {
    if (data.scanResults && Array.isArray(data.scanResults)) {
      // Results already exist, just render them
      renderResults(data.scanResults);
    } else {
      // No stored results, proceed to inject and scan
      startScan();
    }
  });
  
  function startScan() {
    translateUI();
    resultsList.innerHTML = '';
    status.textContent = translations[language].scanning;
    chrome.storage.local.remove('scanResults');

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) return;
      console.log("Injecting content.js into tab", tabs[0].id);

      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        files: ['libs/jsQR.js', 'content.js']
      }, (injectionResults) => {
       if (chrome.runtime.lastError) {
         console.error("Injection error:", chrome.runtime.lastError);
       } else {
          console.log("Injection succeeded:", injectionResults);
       }
      });
    });
  }


  startScan();
});
