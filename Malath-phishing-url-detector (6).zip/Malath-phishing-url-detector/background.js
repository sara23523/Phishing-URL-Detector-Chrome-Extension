chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("BG got message:", message);
  if (message.action === "scan_urls") {
    const urls = message.urls;

    const classifyURL = (url) => {
      const requestBody = {
        model: "openpipe:Malath-GPT",
        messages: [
          { role: "system", content: "You are an AI that classifies URLs as phishing (0) or legitimate (1)." },
          { role: "user", content: `Is this URL phishing or legitimate? ${url}` }
        ],
        store: true,
        temperature: 0
      };

      return fetch("https://app.openpipe.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer opk_3553e3a9255ed88a6bf7e64f899627e0247d844aed"
        },
        body: JSON.stringify(requestBody)
      })
      .then(response => response.json())
      .then(data => {
        console.log("OpenPipe Response:", data); // 🔍 DEBUG
        const classification = data.choices?.[0]?.message?.content?.trim() || "Unknown";
        return { url, classification };
      })
      .catch(error => {
        console.error("API Error:", error);
        return { url, classification: "Failed to process" };
      });
    };

    Promise.all(urls.map(classifyURL))
      .then(results => {
        chrome.storage.local.set({ scanResults: results });
        sendResponse(results); // ✅ respond to sender
      });

    return true; // 🧠 keep message channel open for async
  }
});
